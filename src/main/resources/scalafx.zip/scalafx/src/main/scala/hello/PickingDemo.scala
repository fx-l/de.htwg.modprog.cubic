package scalafx.graphics3d

import scalafx.Includes._
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.scene._
import scalafx.scene.paint.{Color, PhongMaterial}
import scalafx.scene.shape.{Sphere, Box}
import scalafx.scene.transform.Rotate
import scalafx.beans.property.DoubleProperty
import scalafx.scene.input.MouseEvent

/** Illustrates picking of 3D objects.
  * When user picks (clocks) on an object in a 3D scene the object name is printed to console. */
object PickingDemo extends JFXApp {
  
  val sphereSize = 50
  val sphereMargin = 200

  stage = new PrimaryStage {
    title = "Picking Demo"
    scene = new Scene(800, 800, true,  SceneAntialiasing.Balanced) {
      
    
      // Put shapes in a groups so they can be rotated together
      val shapes = new Group
      shapes.children = createSpheres

      val light = new PointLight {
        color = Color.AntiqueWhite
        translateX = -265
        translateY = -260
        translateZ = -625
      }

      root = new Group {
        // Put light outside of `shapes` group so it does not rotate
        content = new Group(shapes, light)
        translateX = 250
        translateY = 250
        translateZ = 825
        rotationAxis = Rotate.YAxis
      }

      camera = new PerspectiveCamera(false)

      addMouseInteraction(this, shapes)
    }
  }

  /** Add mouse interaction to a scene, rotating given node. */
  private def addMouseInteraction(scene: Scene, group: Group) {
    val angleY = DoubleProperty(-50)
    val yRotate = new Rotate {
      angle <== angleY
      axis = Rotate.YAxis
    }
    var anchorX: Double = 0
    var anchorAngleY: Double = 0

    group.transforms = Seq(yRotate)

    scene.onMousePressed = (event: MouseEvent) => {
      anchorAngleY = angleY()
      anchorX = event.sceneX

      // Retrieve information about a pick
      val pickResult = event.pickResult

      // If picked on a Node, place green marker at the location of the pick
      pickResult.intersectedNode match {
        case Some(n) => {
          println("Picked node: '" + n.id() + "'")
          val p = pickResult.intersectedPoint
          group.content += createMarker(x = p.x + n.translateX(), y = p.y + n.translateY(), z = p.z + n.translateZ())
        }
        case None => println("Picked nothing.")
      }
    }

    scene.onMouseDragged = (event: MouseEvent) => {
      angleY() = anchorAngleY + anchorX - event.sceneX
    }


  }

  private def createMarker(x: Double, y: Double, z: Double) : Sphere = new Sphere(35) {
    material = new PhongMaterial {
      diffuseColor = Color.Gold
      specularColor = Color.LightGreen
    }
    translateX = x
    translateY = y
    translateZ = z
  }
  
  def createSpheres = {
    for(x <- 0 until 4; y <- 0 until 4; z <- 0 until 4) 
      yield(
          new Sphere(sphereSize) {
            material = new PhongMaterial {
              diffuseColor = Color.Red
              specularColor = Color.Pink
            }
            translateX = x * sphereMargin
            translateY = y * sphereMargin
            translateZ = z * sphereMargin
            id = x + "-" + y + "-" + z
          }
      )
  }
  
  
}